
//a. //b. filter and map for tax

let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]
printfn "Salaries: %A" salaries
let highIncomeSalaries = salaries |> List.filter (fun salary -> salary > 100000)
printfn "High-Income Salaries: %A" highIncomeSalaries

let calculateTax salary =
    if salary <= 49020 then float salary * 0.15
    elif salary <= 98040 then float salary * 0.205
    elif salary <= 151978 then float salary * 0.26
    elif salary <= 216511 then float salary * 0.29
    else float salary * 0.33
let salariesAndTaxes = salaries |> List.map (fun salary -> (salary, calculateTax salary))
salariesAndTaxes |> List.iter (fun (salary, tax) -> printfn "Salary: %d, Tax: %.2f" salary tax)


//c. 
let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]
let filteredSalaries = List.filter (fun salary -> salary < 49020) salaries
let updatedSalaries = List.map (fun salary -> salary + 20000) filteredSalaries
printfn "%A" updatedSalaries

//d. 
let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]
let filteredSalaries = 
    salaries
    |> List.filter (fun salary -> salary >= 50000 && salary <= 100000)
let totalSum = 
    filteredSalaries
    |> List.fold (fun acc salary -> acc + salary) 0
printfn "Total Sum: %d" totalSum


//Tail Recursion
let sumMultiplesOf3 n =
    let rec sumHelper current accumulator =
        if current > n then
            accumulator
        else
            sumHelper (current + 3) (accumulator + current)
    sumHelper 3 0
let result = sumMultiplesOf3 27
printfn "The sum of all multiples of 3 up to 27 is: %d" result
